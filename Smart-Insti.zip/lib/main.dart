import 'package:flutter/material.dart';
import 'package:flutterapp/smart_instiapp/generatedloginpagewidget/GeneratedLoginPageWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedtodowidget/GeneratedToDoWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/GeneratedCalenderWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedlostandfoundwidget/GeneratedLostandFoundWidget.dart';
import 'package:flutterapp/smart_instiapp/generatednavbarwidget/GeneratedNavBarWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedmessupdatewidget/GeneratedMessUpdateWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedimpinfowidget/GeneratedImpInfoWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedtimetablewidget/GeneratedTimetableWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedotherappswidget/GeneratedOtherAppsWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedhomepagewidget/GeneratedHomePageWidget.dart';

void main() {
  runApp(Smart_InstiApp());
}

class Smart_InstiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedHomePageWidget',
      routes: {
        '/GeneratedLoginPageWidget': (context) => GeneratedLoginPageWidget(),
        '/GeneratedToDoWidget': (context) => GeneratedToDoWidget(),
        '/GeneratedCalenderWidget': (context) => GeneratedCalenderWidget(),
        '/GeneratedLostandFoundWidget': (context) =>
            GeneratedLostandFoundWidget(),
        '/GeneratedNavBarWidget': (context) => GeneratedNavBarWidget(),
        '/GeneratedMessUpdateWidget': (context) => GeneratedMessUpdateWidget(),
        '/GeneratedImpInfoWidget': (context) => GeneratedImpInfoWidget(),
        '/GeneratedTimetableWidget': (context) => GeneratedTimetableWidget(),
        '/GeneratedOtherAppsWidget': (context) => GeneratedOtherAppsWidget(),
        '/GeneratedHomePageWidget': (context) => GeneratedHomePageWidget(),
      },
    );
  }
}
