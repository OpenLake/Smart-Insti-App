import 'package:flutter/material.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget11.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget23.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget29.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget8.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget20.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget5.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget10.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget2.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget6.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget28.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget27.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget16.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget12.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget32.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget22.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget34.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget17.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget6.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget.dart';
import 'package:flutterapp/helpers/transform/transform.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget3.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget19.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget1.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget5.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget3.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget33.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget7.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget4.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget15.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget9.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget4.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget25.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget13.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget14.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget1.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget18.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget26.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget30.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget24.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayabbreviationRobotoWidget2.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget21.dart';
import 'package:flutterapp/smart_instiapp/generatedcalenderwidget/generated/GeneratedDatepickerandroiddayRobotoWidget31.dart';

/* Instance date-picker / android / month / Roboto
    Autogenerated by FlutLab FTF Generator
  */
class GeneratedDatepickerandroidmonthRobotoWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 360.0,
      height: 312.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget1()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget2()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget3()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget4()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget5()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: -120.00,
                  z: 0,
                  child:
                      GeneratedDatepickerandroiddayabbreviationRobotoWidget6()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget1()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget2()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget3()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -144.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget4()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget5()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget6()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget7()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget8()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -96.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget9()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget10()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget11()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget12()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget13()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: -48.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget14()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget15()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget16()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget17()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget18()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 0.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget19()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget20()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget21()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget22()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget23()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 48.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget24()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget25()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget26()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget27()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget28()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 96.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget29()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: -72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget30()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: -24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget31()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: 24.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget32()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: 72.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget33()),
            ),
            Positioned(
              left: null,
              top: null,
              right: null,
              bottom: null,
              width: 40.0,
              height: 40.0,
              child: TransformHelper.translate(
                  x: 144.00,
                  y: 120.00,
                  z: 0,
                  child: GeneratedDatepickerandroiddayRobotoWidget34()),
            )
          ]),
    );
  }
}
